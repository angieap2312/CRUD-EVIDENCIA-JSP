package com.example.demo.controller;

import com.example.demo.dao.entities.Estudiante;
import com.example.demo.services.CrudService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/estudiante")
public class EstudianteController {

    @Autowired
    private CrudService crudService;

    // Mostrar la lista de artículos
    @GetMapping
    public String listarestudiante(Model model) {
        model.addAttribute("estudiantes", crudService.obtenerTodosLosEstudiantes());
        return "lista-estudiantes";
    }

    /*/ Mostrar formulario para crear un nuevo artículo
    @GetMapping("/nuevo")
    public String mostrarFormularioDeCrear(Model model) {
        model.addAttribute("articulo", new Articulo());
        return "articulo-form";
    }

    // Guardar el nuevo artículo
    @PostMapping
    public String guardarArticulo(@ModelAttribute("articulo") Articulo articulo) {
        crudService.guardarArticulo(articulo);
        return "redirect:/estudiante";
    }

    // Mostrar formulario para editar un artículo existente
    @GetMapping("/editar/{id}")
    public String mostrarFormularioDeEditar(@PathVariable("id") Long id, Model model) {
        model.addAttribute("articulo", crudService.obtenerArticuloPorId(id));
        return "articulo-form";
    }

    // Actualizar artículo existente
    @PostMapping("/{id}")
    public String actualizarArticulo(@PathVariable("id") Long id, @ModelAttribute("articulo") Articulo articulo) {
        crudService.actualizarArticulo(id, articulo);
        return "redirect:/estudiante";
    }

    // Eliminar artículo
    @GetMapping("/eliminar/{id}")
    public String eliminarArticulo(@PathVariable("id") Long id) {
        crudService.eliminarArticulo(id);
        return "redirect:/estudiante";
    }*/
}